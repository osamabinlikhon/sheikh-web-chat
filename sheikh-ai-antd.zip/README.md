# Sheikh AI - Modern AI-Powered Web Experience

A comprehensive AI-powered web application built with Firebase Authentication and Ant Design X, featuring a modern chat interface with streaming support.

## 🚀 Features

### Authentication
- **Email/Password Authentication** - Secure user registration and login
- **Google Sign-In** - Quick and easy authentication with Google accounts
- **Protected Routes** - Secure access to chat functionality
- **Real-time Auth State** - Instant user state management

### AI Interface (Ant Design X)
- **Conversational Bubbles** - Modern chat message UI with role-based styling
- **Streaming Markdown Support** - Rich text rendering for AI responses
- **Quick Prompts** - Pre-defined prompts for common queries
- **Conversation History** - Sidebar with recent conversations
- **Responsive Design** - Mobile-friendly chat interface

### User Experience
- **Modern UI** - Clean, professional design with Sheikh brand colors
- **Loading States** - Visual feedback during operations
- **Error Handling** - User-friendly error messages
- **Dark Mode Ready** - Foundation for future dark theme support

## 📦 Tech Stack

- **Frontend**: React 18 with TypeScript
- **UI Framework**: Ant Design 5.x
- **AI Components**: Ant Design X 2.x
- **Authentication**: Firebase Auth
- **Routing**: React Router v6
- **Build Tool**: Vite

## 🛠️ Installation

1. **Clone the repository**
   ```bash
   cd /workspace/sheikh-ai
   ```

2. **Install dependencies**
   ```bash
   npm install
   # or
   pnpm install
   ```

3. **Configure Firebase**
   - Update `src/config/firebase.ts` with your Firebase configuration
   - Enable Email/Password and Google authentication in Firebase Console

4. **Start development server**
   ```bash
   npm run dev
   ```

5. **Open browser**
   Navigate to `http://localhost:3000`

## 📁 Project Structure

```
sheikh-ai/
├── src/
│   ├── components/
│   │   └── Logo.tsx           # Sheikh brand logo component
│   ├── config/
│   │   └── firebase.ts        # Firebase configuration
│   ├── context/
│   │   └── AuthContext.tsx    # Authentication context & hooks
│   ├── hooks/
│   │   └── useAIChat.ts       # Custom chat hook
│   ├── pages/
│   │   ├── Login.tsx          # Login page
│   │   ├── Register.tsx       # Registration page
│   │   └── Chat.tsx           # AI chat interface
│   ├── styles/
│   │   └── global.css         # Global styles
│   ├── App.tsx                # Main app component
│   └── main.tsx               # Application entry point
├── index.html
├── package.json
├── tsconfig.json
└── vite.config.ts
```

## 🔧 Configuration

### Firebase Setup

1. Create a Firebase project at [Firebase Console](https://console.firebase.google.com)
2. Enable Authentication:
   - Email/Password provider
   - Google provider
3. Copy your web app configuration
4. Update `src/config/firebase.ts`:
   ```typescript
   const firebaseConfig = {
     apiKey: "YOUR_API_KEY",
     authDomain: "YOUR_PROJECT.firebaseapp.com",
     projectId: "YOUR_PROJECT_ID",
     storageBucket: "YOUR_PROJECT.firebasestorage.app",
     messagingSenderId: "YOUR_SENDER_ID",
     appId: "YOUR_APP_ID"
   }
   ```

### AI Integration

The chat interface is designed to work with any AI API. To integrate with a real AI service:

1. Update `src/hooks/useAIChat.ts` with your API endpoint
2. Add API key handling (consider using a backend proxy)
3. Implement streaming response handling

Example integration:
```typescript
const response = await fetch('https://api.your-ai-service.com/v1/chat', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer YOUR_API_KEY`
  },
  body: JSON.stringify({
    messages: [{ role: 'user', content: userInput }]
  })
})
```

## 🎨 Customization

### Brand Colors

 Sheikh brand colors used throughout:
- **Red**: `#E31837`
- **Green**: `#009639`
- **Black**: `#1D1D1B`

Update these in:
- `src/components/Logo.tsx`
- `src/pages/Login.tsx`
- `src/pages/Register.tsx`
- `src/pages/Chat.tsx`

### Theme Customization

Modify the theme in `src/main.tsx`:
```typescript
const theme = {
  token: {
    colorPrimary: '#009639',
    borderRadius: 8,
  }
}
```

## 📱 Responsive Design

The application is fully responsive with:
- Mobile-first approach
- Collapsible sidebar on mobile
- Touch-friendly controls
- Adaptive layouts

## 🔒 Security Considerations

- Firebase Authentication handles secure user sessions
- Protected routes prevent unauthorized access
- Environment variables should be used for sensitive keys in production
- Consider implementing rate limiting for AI API calls

## 🚀 Deployment

1. **Build the application**
   ```bash
   npm run build
   ```

2. **Deploy to Firebase Hosting**
   ```bash
   firebase init hosting
   npm run build
   firebase deploy
   ```

## 📄 License

MIT License - feel free to use this project for your own purposes.

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📧 Support

For questions or support, please open an issue in the repository.

---

Built with ❤️ using Firebase and Ant Design X
