import { createContext, useContext, useEffect, useState, ReactNode } from 'react'
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  User,
  UserCredential
} from 'firebase/auth'
import { auth, googleProvider } from '../config/firebase'

interface AuthContextType {
  user: User | null
  loading: boolean
  signInWithEmail: (email: string, password: string) => Promise<UserCredential>
  signUpWithEmail: (email: string, password: string) => Promise<UserCredential>
  signInWithGoogle: () => Promise<UserCredential>
  logout: () => Promise<void>
  error: string | null
  clearError: () => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function useAuth(): AuthContextType {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

interface AuthProviderProps {
  children: ReactNode
}

export function AuthProvider({ children }: AuthProviderProps): JSX.Element {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // Listen for authentication state changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser)
      setLoading(false)
    })

    return () => unsubscribe()
  }, [])

  const signInWithEmail = async (email: string, password: string): Promise<UserCredential> => {
    try {
      setError(null)
      return await signInWithEmailAndPassword(auth, email, password)
    } catch (err: unknown) {
      const firebaseError = err as { code: string; message: string }
      const errorMessage = getFirebaseErrorMessage(firebaseError.code)
      setError(errorMessage)
      throw new Error(errorMessage)
    }
  }

  const signUpWithEmail = async (email: string, password: string): Promise<UserCredential> => {
    try {
      setError(null)
      return await createUserWithEmailAndPassword(auth, email, password)
    } catch (err: unknown) {
      const firebaseError = err as { code: string; message: string }
      const errorMessage = getFirebaseErrorMessage(firebaseError.code)
      setError(errorMessage)
      throw new Error(errorMessage)
    }
  }

  const signInWithGoogle = async (): Promise<UserCredential> => {
    try {
      setError(null)
      return await signInWithPopup(auth, googleProvider)
    } catch (err: unknown) {
      const firebaseError = err as { code: string; message: string }
      const errorMessage = getFirebaseErrorMessage(firebaseError.code)
      setError(errorMessage)
      throw new Error(errorMessage)
    }
  }

  const logout = async (): Promise<void> => {
    try {
      setError(null)
      await signOut(auth)
    } catch (err: unknown) {
      const firebaseError = err as { code: string; message: string }
      const errorMessage = getFirebaseErrorMessage(firebaseError.code)
      setError(errorMessage)
      throw new Error(errorMessage)
    }
  }

  const clearError = (): void => {
    setError(null)
  }

  const value: AuthContextType = {
    user,
    loading,
    signInWithEmail,
    signUpWithEmail,
    signInWithGoogle,
    logout,
    error,
    clearError
  }

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  )
}

function getFirebaseErrorMessage(code: string): string {
  const errorMessages: Record<string, string> = {
    'auth/user-not-found': 'No account found with this email address.',
    'auth/wrong-password': 'Incorrect password. Please try again.',
    'auth/email-already-in-use': 'This email is already registered.',
    'auth/weak-password': 'Password should be at least 6 characters.',
    'auth/invalid-email': 'Please enter a valid email address.',
    'auth/popup-closed-by-user': 'Sign-in popup was closed.',
    'auth/network-request-failed': 'Network error. Please check your connection.',
    'auth/too-many-requests': 'Too many attempts. Please try again later.',
    'auth/user-disabled': 'This account has been disabled.',
    'auth/account-exists-with-different-credential': 'An account already exists with this email.'
  }
  return errorMessages[code] || 'An error occurred. Please try again.'
}
