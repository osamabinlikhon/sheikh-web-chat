import { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react'

interface NetworkContextType {
  isOnline: boolean
  isPWAInstalled: boolean
  installPWA: () => Promise<void>
  deferredPrompt: Event | null
  checkOnlineStatus: () => boolean
}

const NetworkContext = createContext<NetworkContextType | undefined>(undefined)

export function useNetwork(): NetworkContextType {
  const context = useContext(NetworkContext)
  if (!context) {
    throw new Error('useNetwork must be used within a NetworkProvider')
  }
  return context
}

interface NetworkProviderProps {
  children: ReactNode
}

export function NetworkProvider({ children }: NetworkProviderProps): JSX.Element {
  const [isOnline, setIsOnline] = useState(true)
  const [deferredPrompt, setDeferredPrompt] = useState<Event | null>(null)
  const [isPWAInstalled, setIsPWAInstalled] = useState(false)

  const checkOnlineStatus = useCallback((): boolean => {
    return navigator.onLine
  }, [])

  useEffect(() => {
    // Set initial status
    setIsOnline(checkOnlineStatus())

    // Listen for online/offline events
    const handleOnline = (): void => {
      setIsOnline(true)
      console.log('Network restored: Online')
    }

    const handleOffline = (): void => {
      setIsOnline(false)
      console.log('Network lost: Offline mode activated')
    }

    window.addEventListener('online', handleOnline)
    window.addEventListener('offline', handleOffline)

    // Listen for PWA install prompt
    const handleBeforeInstallPrompt = (e: Event): void => {
      e.preventDefault()
      setDeferredPrompt(e)
      console.log('PWA install prompt available')
    }

    // Check if app is already installed
    const handleAppInstalled = (): void => {
      setIsPWAInstalled(true)
      setDeferredPrompt(null)
      console.log('PWA installed successfully')
    }

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt)
    window.addEventListener('appinstalled', handleAppInstalled)

    // Check if running in standalone mode (installed PWA)
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsPWAInstalled(true)
    }

    // Cleanup
    return () => {
      window.removeEventListener('online', handleOnline)
      window.removeEventListener('offline', handleOffline)
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt)
      window.removeEventListener('appinstalled', handleAppInstalled)
    }
  }, [checkOnlineStatus])

  const installPWA = useCallback(async (): Promise<void> => {
    if (!deferredPrompt) {
      console.log('No install prompt available')
      return
    }

    // Show the install prompt
    const promptEvent = deferredPrompt as any
    await promptEvent.prompt()

    // Wait for the user to respond
    const { outcome } = await promptEvent.userChoice

    console.log(`User response to install prompt: ${outcome}`)

    // Clear the prompt
    setDeferredPrompt(null)

    if (outcome === 'accepted') {
      setIsPWAInstalled(true)
    }
  }, [deferredPrompt])

  const value: NetworkContextType = {
    isOnline,
    isPWAInstalled,
    installPWA,
    deferredPrompt,
    checkOnlineStatus
  }

  return (
    <NetworkContext.Provider value={value}>
      {children}
    </NetworkContext.Provider>
  )
}

export default NetworkContext
