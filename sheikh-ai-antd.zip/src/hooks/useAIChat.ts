import { useState, useCallback, useRef } from 'react'

interface Message {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp: number
}

interface UseAIChatOptions {
  maxMessages?: number
  onError?: (error: Error) => void
}

interface UseAIChatReturn {
  messages: Message[]
  loading: boolean
  sendMessage: (content: string) => Promise<void>
  clearMessages: () => void
  stopGenerating: () => void
}

export function useAIChat(options: UseAIChatOptions = {}): UseAIChatReturn {
  const { maxMessages = 100, onError } = options
  const [messages, setMessages] = useState<Message[]>([])
  const [loading, setLoading] = useState(false)
  const abortControllerRef = useRef<AbortController | null>(null)

  const sendMessage = useCallback(async (content: string): Promise<void> => {
    if (!content.trim() || loading) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: content.trim(),
      timestamp: Date.now()
    }

    setMessages(prev => [...prev.slice(-maxMessages + 1), userMessage])
    setLoading(true)

    try {
      // Create abort controller for cancellation
      abortControllerRef.current = new AbortController()
      const { signal } = abortControllerRef.current

      // Simulate API call - replace with actual AI API integration
      const response = await simulateAIResponse(content.trim(), signal)

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response,
        timestamp: Date.now()
      }

      setMessages(prev => [...prev.slice(-maxMessages), assistantMessage])
    } catch (error) {
      if (error instanceof Error && error.name === 'AbortError') {
        // Request was cancelled
        return
      }
      const errorMessage = error instanceof Error ? error : new Error('Unknown error')
      onError?.(errorMessage)
    } finally {
      setLoading(false)
      abortControllerRef.current = null
    }
  }, [loading, maxMessages, onError])

  const clearMessages = useCallback(() => {
    setMessages([])
  }, [])

  const stopGenerating = useCallback(() => {
    abortControllerRef.current?.abort()
    setLoading(false)
  }, [])

  return {
    messages,
    loading,
    sendMessage,
    clearMessages,
    stopGenerating
  }
}

// Simulate AI response (replace with actual API integration)
async function simulateAIResponse(
  input: string,
  signal: AbortSignal
): Promise<string> {
  // Simulate network delay
  await new Promise((resolve, reject) => {
    const timeout = setTimeout(resolve, 1000 + Math.random() * 1000)
    signal.addEventListener('abort', () => {
      clearTimeout(timeout)
      reject(new DOMException('Aborted', 'AbortError'))
    })
  })

  // Generate contextual response
  const responses = [
    `I understand you're asking about "${input.substring(0, 30)}${input.length > 30 ? '...' : ''}". Let me provide you with a comprehensive answer based on my knowledge.`,
    `That's an excellent question! Here's what I can tell you about "${input.substring(0, 30)}${input.length > 30 ? '...' : ''}".`,
    `I'm here to help with your inquiry about "${input.substring(0, 30)}${input.length > 30 ? '...' : ''}". Based on my understanding, I can offer the following insights.`,
    `Thank you for your question. Regarding "${input.substring(0, 30)}${input.length > 30 ? '...' : ''}", I recommend considering these key points.`
  ]

  const baseResponse = responses[Math.floor(Math.random() * responses.length)]

  // Add helpful follow-up content
  const followUpContent = `

Additionally, here are some relevant points to consider:
- This is a simulated response for demonstration purposes
- In a production environment, you would connect to a real AI API
- The response can be customized based on your specific needs

Is there anything specific you'd like me to elaborate on?`

  return baseResponse + followUpContent
}

export default useAIChat
