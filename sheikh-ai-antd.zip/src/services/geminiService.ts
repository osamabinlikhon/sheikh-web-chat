/**
 * Gemini AI Service Integration
 * 
 * IMPORTANT: API keys should be stored securely in environment variables.
 * In production, API calls should be made through your own backend server
 * to protect your API credentials.
 */

const API_KEY = import.meta.env.VITE_GEMINI_API_KEY || ''

interface GeminiRequest {
  contents: Array<{
    parts: Array<{ text: string }>
  }>
}

interface GeminiResponse {
  candidates?: Array<{
    content?: {
      parts?: Array<{ text: string }>
    }
    safetyRatings?: Array<{
      category: string
      probability: string
    }>
  }>
  promptFeedback?: {
    blockReason: string
  }
}

interface SendMessageOptions {
  signal?: AbortSignal
  onStream?: (chunk: string) => void
}

class GeminiService {
  private apiKey: string
  private baseUrl: string

  constructor(apiKey: string = '') {
    this.apiKey = apiKey
    this.baseUrl = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-3-pro-preview:generateContent'
  }

  setApiKey(key: string): void {
    this.apiKey = key
  }

  async sendMessage(
    message: string,
    history: Array<{ role: 'user' | 'assistant'; content: string }> = [],
    options: SendMessageOptions = {}
  ): Promise<string> {
    const { signal } = options

    if (!this.apiKey) {
      throw new Error('Gemini API key is not configured. Please set VITE_GEMINI_API_KEY in your environment.')
    }

    // Build conversation context
    const contents = [
      ...history.map(msg => ({
        role: msg.role === 'user' ? 'user' : 'model',
        parts: [{ text: msg.content }]
      })),
      {
        role: 'user',
        parts: [{ text: message }]
      }
    ]

    const requestBody: GeminiRequest = {
      contents: contents.map(msg => ({
        parts: msg.parts
      }))
    }

    try {
      const response = await fetch(`${this.baseUrl}?key=${this.apiKey}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestBody),
        signal
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error?.message || `API request failed with status ${response.status}`)
      }

      const data: GeminiResponse = await response.json()

      // Check for blocking or safety issues
      if (data.promptFeedback?.blockReason) {
        throw new Error(`Content was blocked due to: ${data.promptFeedback.blockReason}`)
      }

      // Extract response text
      const candidate = data.candidates?.[0]
      if (!candidate?.content?.parts?.[0]?.text) {
        throw new Error('No response content received from Gemini')
      }

      return candidate.content.parts[0].text

    } catch (error) {
      if (error instanceof Error && error.name === 'AbortError') {
        throw error
      }
      throw error
    }
  }

  // Streaming response support (for future implementation)
  async sendMessageStream(
    message: string,
    history: Array<{ role: 'user' | 'assistant'; content: string }> = [],
    options: SendMessageOptions = {}
  ): Promise<string> {
    // For now, use non-streaming API
    // Streaming can be added with fetch ReadableStream
    return this.sendMessage(message, history, options)
  }

  validateApiKey(): boolean {
    return Boolean(this.apiKey && this.apiKey.length > 0)
  }
}

// Export singleton instance
export const geminiService = new GeminiService(API_KEY)

// Export class for custom instances
export { GeminiService }

// Helper function to format messages for Gemini
export function formatConversationHistory(
  messages: Array<{ role: 'user' | 'assistant'; content: string }>
): Array<{ role: 'user' | 'assistant'; content: string }> {
  // Keep last 20 messages to stay within token limits
  return messages.slice(-20)
}

export default geminiService
