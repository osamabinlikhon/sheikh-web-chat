import { initializeApp } from 'firebase/app'
import { getAuth, GoogleAuthProvider } from 'firebase/auth'

// Firebase configuration from Sheikh BD project
const firebaseConfig = {
  apiKey: "AIzaSyBrNG7RruWeQciIpXdYwoeT0faM-x1rgzc",
  authDomain: "sheikh-bd.firebaseapp.com",
  projectId: "sheikh-bd",
  storageBucket: "sheikh-bd.firebasestorage.app",
  messagingSenderId: "31053996432",
  appId: "1:31053996432:web:8a3c6a988bba6939849315"
}

// Initialize Firebase application
const app = initializeApp(firebaseConfig)

// Initialize Firebase Authentication
export const auth = getAuth(app)

// Configure Google Auth Provider
export const googleProvider = new GoogleAuthProvider()
googleProvider.setCustomParameters({
  prompt: 'select_account'
})

export default app
