import React from 'react'
import { Typography } from 'antd'

const { Text } = Typography

interface LogoProps {
  size?: 'small' | 'medium' | 'large'
  showText?: boolean
}

const Logo: React.FC<LogoProps> = ({ size = 'medium', showText = true }) => {
  const getSizeStyles = () => {
    switch (size) {
      case 'small':
        return { icon: 24, fontSize: 16 }
      case 'large':
        return { icon: 48, fontSize: 32 }
      default:
        return { icon: 36, fontSize: 24 }
    }
  }

  const { icon, fontSize } = getSizeStyles()

  // Sheikh brand colors from the logo
  const colors = {
    red: '#E31837',
    green: '#009639',
    black: '#1D1D1B'
  }

  const containerStyle: React.CSSProperties = {
    display: 'flex',
    alignItems: 'center',
    gap: size === 'small' ? 6 : 12
  }

  const textStyle: React.CSSProperties = {
    fontSize,
    fontWeight: 700,
    letterSpacing: '-0.5px',
    color: colors.black,
    lineHeight: 1.2
  }

  const iconStyle: React.CSSProperties = {
    width: icon,
    height: icon,
    position: 'relative' as const
  }

  return (
    <div style={containerStyle}>
      {/* Sheikh Brand Icon - Stylized Text Mark */}
      <svg
        viewBox="0 0 48 48"
        style={iconStyle}
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Background rounded square */}
        <rect
          x="2"
          y="2"
          width="44"
          height="44"
          rx="8"
          fill={colors.black}
        />
        {/* Stylized 'S' shape with brand colors */}
        <path
          d="M16 14 C12 14 10 16 10 19 L10 24 C10 27 12 29 16 29 L20 29 L20 34 C20 37 22 39 25 39 C28 39 30 37 30 34 L30 29 C34 29 36 27 36 24 L36 19 C36 16 34 14 30 14 L26 14 L26 9 C26 6 24 4 21 4 C18 4 16 6 16 9 L16 14 Z"
          fill="white"
        />
        {/* Color accent dots */}
        <circle cx="13" cy="19" r="3" fill={colors.red} />
        <circle cx="33" cy="24" r="3" fill={colors.green} />
      </svg>

      {showText && (
        <Text style={textStyle}>
          <span style={{ color: colors.red }}>Sheikh</span>
          <span style={{ color: colors.black }}> AI</span>
        </Text>
      )}
    </div>
  )
}

export default Logo
