/// <reference lib="webworker" />

const CACHE_NAME = 'sheikh-ai-v1';
const STATIC_CACHE = 'static-v1';
const DYNAMIC_CACHE = 'dynamic-v1';
const API_CACHE = 'api-v1';
const OFFLINE_URL = '/offline.html';

// Assets to cache immediately on install
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/offline.html',
  '/manifest.json',
  '/favicon.ico'
];

// Install event - cache static assets
self.addEventListener('install', (event: ExtendableEvent) => {
  console.log('[ServiceWorker] Install');
  
  event.waitUntil(
    caches.open(STATIC_CACHE)
      .then((cache) => {
        console.log('[ServiceWorker] Caching static assets');
        return cache.addAll(STATIC_ASSETS);
      })
      .then(() => {
        console.log('[ServiceWorker] Skip waiting');
        return self.skipWaiting();
      })
      .catch((error) => {
        console.error('[ServiceWorker] Install failed:', error);
      })
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', (event: ExtendableEvent) => {
  console.log('[ServiceWorker] Activate');
  
  event.waitUntil(
    caches.keys()
      .then((cacheNames) => {
        return Promise.all(
          cacheNames
            .filter((cacheName) => {
              return cacheName !== STATIC_CACHE && 
                     cacheName !== DYNAMIC_CACHE && 
                     cacheName !== API_CACHE &&
                     cacheName !== CACHE_NAME;
            })
            .map((cacheName) => {
              console.log('[ServiceWorker] Deleting old cache:', cacheName);
              return caches.delete(cacheName);
            })
        );
      })
      .then(() => {
        console.log('[ServiceWorker] Claiming clients');
        return self.clients.claim();
      })
  );
});

// Fetch event - implement caching strategies
self.addEventListener('fetch', (event: FetchEvent) => {
  const { request } = event;
  const url = new URL(request.url);

  // Skip non-GET requests
  if (request.method !== 'GET') {
    // Handle POST requests for offline support
    if (request.method === 'POST' && !navigator.onLine) {
      event.respondWith(handleOfflineRequest(request));
      return;
    }
    return;
  }

  // Skip cross-origin requests (except for specific domains)
  if (url.origin !== location.origin) {
    // Allow Google APIs and Firebase
    if (url.hostname.includes('googleapis.com') ||
        url.hostname.includes('firebaseio.com') ||
        url.hostname.includes('firebasestorage.app') ||
        url.hostname.includes('google.com')) {
      event.respondWith(handleExternalRequest(request));
      return;
    }
    return;
  }

  // Handle navigation requests (HTML pages)
  if (request.mode === 'navigate') {
    event.respondWith(handleNavigationRequest(request));
    return;
  }

  // Handle API requests
  if (url.pathname.includes('/api/') || url.pathname.includes('/generateContent')) {
    event.respondWith(handleAPIRequest(request));
    return;
  }

  // Handle static assets - Cache First strategy
  event.respondWith(handleStaticRequest(request));
});

// Cache First strategy for static assets
async function handleStaticRequest(request: Request): Promise<Response> {
  const cachedResponse = await caches.match(request);
  
  if (cachedResponse) {
    // Return cached version and update cache in background
    fetchAndCache(request, DYNAMIC_CACHE);
    return cachedResponse;
  }

  return fetchAndCache(request, DYNAMIC_CACHE);
}

// Network First strategy for navigation
async function handleNavigationRequest(request: Request): Promise<Response> {
  try {
    const networkResponse = await fetch(request);
    
    // Cache the navigation response
    const cache = await caches.open(STATIC_CACHE);
    cache.put(request, networkResponse.clone());
    
    return networkResponse;
  } catch (error) {
    // Network failed, try to return cached version
    const cachedResponse = await caches.match(request);
    if (cachedResponse) {
      return cachedResponse;
    }
    
    // Return offline page as last resort
    const offlineResponse = await caches.match(OFFLINE_URL);
    if (offlineResponse) {
      return offlineResponse;
    }
    
    // Return a basic offline response
    return new Response('Offline', {
      status: 503,
      statusText: 'Service Unavailable',
      headers: new Headers({ 'Content-Type': 'text/plain' })
    });
  }
}

// Network First strategy for API requests
async function handleAPIRequest(request: Request): Promise<Response> {
  const cache = await caches.open(API_CACHE);
  
  try {
    const networkResponse = await fetch(request);
    
    // Cache successful API responses
    if (networkResponse.ok) {
      cache.put(request, networkResponse.clone());
    }
    
    return networkResponse;
  } catch (error) {
    // Network failed, try cached version
    const cachedResponse = await cache.match(request);
    if (cachedResponse) {
      return cachedResponse;
    }
    
    // Return error response for API
    return new Response(JSON.stringify({
      error: 'Network error',
      message: 'You are offline. Please try again when online.'
    }), {
      status: 503,
      statusText: 'Service Unavailable',
      headers: new Headers({ 'Content-Type': 'application/json' })
    });
  }
}

// Network First strategy for external requests (Google APIs, Firebase)
async function handleExternalRequest(request: Request): Promise<Response> {
  const cache = await caches.open(API_CACHE);
  
  try {
    const networkResponse = await fetch(request);
    
    // Cache successful responses
    if (networkResponse.ok) {
      cache.put(request, networkResponse.clone());
    }
    
    return networkResponse;
  } catch (error) {
    // Network failed, try cached version
    const cachedResponse = await cache.match(request);
    if (cachedResponse) {
      return cachedResponse;
    }
    
    throw error;
  }
}

// Fetch and cache helper
async function fetchAndCache(request: Request, cacheName: string): Promise<Response> {
  try {
    const networkResponse = await fetch(request);
    
    if (networkResponse.ok) {
      const cache = await caches.open(cacheName);
      cache.put(request, networkResponse.clone());
    }
    
    return networkResponse;
  } catch (error) {
    console.error('[ServiceWorker] Fetch failed:', error);
    throw error;
  }
}

// Handle offline requests (Background Sync preparation)
async function handleOfflineRequest(request: Request): Promise<Response> {
  // Store request for later sync
  const requestData = await request.clone().text();
  
  const offlineRequest = {
    url: request.url,
    method: request.method,
    headers: Object.fromEntries(request.headers.entries()),
    body: requestData,
    timestamp: Date.now()
  };
  
  // Get existing queued requests
  const queuedRequests = await getQueuedRequests();
  queuedRequests.push(offlineRequest);
  
  // Store queued requests
  await storeQueuedRequests(queuedRequests);
  
  // Schedule background sync
  if ('sync' in self.registration) {
    await self.registration.sync.register('sync-messages');
  }
  
  return new Response(JSON.stringify({
    queued: true,
    message: 'Request queued for sync when online'
  }), {
    status: 202,
    statusText: 'Accepted',
    headers: new Headers({ 'Content-Type': 'application/json' })
  });
}

// Background Sync event
self.addEventListener('sync', (event: SyncEvent) => {
  console.log('[ServiceWorker] Sync event:', event.tag);
  
  if (event.tag === 'sync-messages') {
    event.waitUntil(syncQueuedRequests());
  }
});

// Sync queued requests when back online
async function syncQueuedRequests(): Promise<void> {
  console.log('[ServiceWorker] Syncing queued requests');
  
  const queuedRequests = await getQueuedRequests();
  
  for (const requestData of queuedRequests) {
    try {
      const response = await fetch(requestData.url, {
        method: requestData.method,
        headers: requestData.headers,
        body: requestData.body
      });
      
      if (response.ok) {
        console.log('[ServiceWorker] Synced request:', requestData.url);
        // Remove from queue
        await removeQueuedRequest(requestData);
      }
    } catch (error) {
      console.error('[ServiceWorker] Failed to sync request:', requestData.url);
    }
  }
}

// Helper functions for queued requests storage
async function getQueuedRequests(): Promise<any[]> {
  const cache = await caches.open('sync-queue');
  const response = await cache.match('pending-requests');
  
  if (response) {
    return response.json();
  }
  
  return [];
}

async function storeQueuedRequests(requests: any[]): Promise<void> {
  const cache = await caches.open('sync-queue');
  await cache.put(
    'pending-requests',
    new Response(JSON.stringify(requests))
  );
}

async function removeQueuedRequest(requestData: any): Promise<void> {
  const requests = await getQueuedRequests();
  const filtered = requests.filter(r => r.timestamp !== requestData.timestamp);
  await storeQueuedRequests(filtered);
}

// Push notification event
self.addEventListener('push', (event: PushEvent) => {
  console.log('[ServiceWorker] Push received');
  
  let data = {
    title: 'Sheikh AI',
    body: 'New notification',
    icon: '/icons/icon-192x192.png',
    badge: '/icons/icon-72x72.png',
    data: { url: '/' }
  };
  
  if (event.data) {
    try {
      data = { ...data, ...event.data.json() };
    } catch (e) {
      data.body = event.data.text();
    }
  }
  
  const options: NotificationOptions = {
    body: data.body,
    icon: data.icon,
    badge: data.badge,
    vibrate: [100, 50, 100],
    data: data.data,
    actions: [
      { action: 'open', title: 'Open' },
      { action: 'close', title: 'Close' }
    ],
    tag: 'sheikh-ai-notification',
    renotify: true
  };
  
  event.waitUntil(
    self.registration.showNotification(data.title, options)
  );
});

// Notification click event
self.addEventListener('notificationclick', (event: NotificationEvent) => {
  console.log('[ServiceWorker] Notification clicked');
  
  event.notification.close();
  
  if (event.action === 'close') {
    return;
  }
  
  const urlToOpen = event.notification.data?.url || '/';
  
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true })
      .then((clientList) => {
        // Check if there's already a window open
        for (const client of clientList) {
          if (client.url.includes(urlToOpen) && 'focus' in client) {
            return client.focus();
          }
        }
        
        // Open a new window
        if (self.clients.openWindow) {
          return self.clients.openWindow(urlToOpen);
        }
      })
  );
});

// Message event for manual cache operations
self.addEventListener('message', (event: ExtendableMessageEvent) => {
  console.log('[ServiceWorker] Message received:', event.data);
  
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
  
  if (event.data && event.data.type === 'CLEAR_CACHE') {
    event.waitUntil(
      caches.keys()
        .then((cacheNames) => {
          return Promise.all(
            cacheNames.map((cacheName) => caches.delete(cacheName))
          );
        })
        .then(() => {
          event.ports[0].postMessage({ success: true });
        })
    );
  }
  
  if (event.data && event.data.type === 'GET_CACHE_SIZE') {
    event.waitUntil(
      getCacheSize()
        .then((size) => {
          event.ports[0].postMessage({ size });
        })
    );
  }
});

// Helper function to get cache size
async function getCacheSize(): Promise<number> {
  let totalSize = 0;
  
  const cacheNames = await caches.keys();
  
  for (const cacheName of cacheNames) {
    const cache = await caches.open(cacheName);
    const keys = await cache.keys();
    
    for (const request of keys) {
      const response = await cache.match(request);
      if (response) {
        const blob = await response.blob();
        totalSize += blob.size;
      }
    }
  }
  
  return totalSize;
}

export {};
