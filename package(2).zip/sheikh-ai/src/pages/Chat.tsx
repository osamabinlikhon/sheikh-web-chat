import React, { useState, useRef, useEffect } from 'react'
import {
  Layout,
  Typography,
  Button,
  Avatar,
  Dropdown,
  Space,
  message,
  Badge,
  Input
} from 'antd'
import {
  UserOutlined,
  LogoutOutlined,
  RobotOutlined,
  PlusOutlined,
  MenuOutlined,
  SettingOutlined,
  SendOutlined
} from '@ant-design/icons'
import { XProvider } from '@ant-design/x'
import { useAuth } from '../context/AuthContext'
import Logo from '../components/Logo'

const { Text } = Typography
const { Header, Content, Sider } = Layout

interface Message {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp: number
}

// API Configuration
const GEMINI_API_KEY = import.meta.env.VITE_GEMINI_API_KEY || ''
const GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-3-pro-preview:generateContent'

const Chat: React.FC = () => {
  const { user, logout } = useAuth()
  const [messageApi, contextHolder] = message.useMessage()
  const [inputValue, setInputValue] = useState('')
  const [conversations] = useState<Array<{ id: string; title: string }>>([
    { id: '1', title: 'Getting Started with AI' },
    { id: '2', title: 'Code Review Assistant' },
    { id: '3', title: 'Creative Writing Help' }
  ])
  const [activeConversation, setActiveConversation] = useState('1')
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: 'Hello! I am your AI assistant powered by Sheikh AI with Gemini. How can I help you today?',
      timestamp: Date.now()
    }
  ])
  const [loading, setLoading] = useState(false)
  const [siderCollapsed, setSiderCollapsed] = useState(false)
  const [apiKeyMissing, setApiKeyMissing] = useState(!GEMINI_API_KEY)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = (): void => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  // Call Gemini API for AI responses
  const callGeminiAPI = async (
    userInput: string,
    messageHistory: Message[],
    signal: AbortSignal
  ): Promise<string> => {
    if (!GEMINI_API_KEY) {
      throw new Error('API key not configured')
    }

    // Build conversation context
    const contents = messageHistory.map(msg => ({
      role: msg.role === 'user' ? 'user' : 'model',
      parts: [{ text: msg.content }]
    }))

    // Add current message
    contents.push({
      role: 'user',
      parts: [{ text: userInput }]
    })

    const response = await fetch(`${GEMINI_API_URL}?key=${GEMINI_API_KEY}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ contents }),
      signal
    })

    if (!response.ok) {
      const errorData = await response.json()
      throw new Error(errorData.error?.message || `API error: ${response.status}`)
    }

    const data = await response.json()
    
    if (data.promptFeedback?.blockReason) {
      throw new Error(`Content blocked: ${data.promptFeedback.blockReason}`)
    }

    const candidate = data.candidates?.[0]
    if (!candidate?.content?.parts?.[0]?.text) {
      throw new Error('No response from AI')
    }

    return candidate.content.parts[0].text
  }

  // Fallback response when API is not configured
  const generateFallbackResponse = (input: string): string => {
    const responses = [
      `I understand you're asking about "${input.substring(0, 30)}${input.length > 30 ? '...' : ''}". Let me help you with that.`,
      `That's a great question about "${input.substring(0, 30)}${input.length > 30 ? '...' : ''}".`,
      `I can certainly assist with your inquiry about "${input.substring(0, 30)}${input.length > 30 ? '...' : ''}".`,
      `Based on your question regarding "${input.substring(0, 30)}${input.length > 30 ? '...' : ''}", here's what I recommend.`
    ]
    return responses[Math.floor(Math.random() * responses.length)]
  }

  const handleSend = async (): Promise<void> => {
    if (!inputValue.trim() || loading) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue.trim(),
      timestamp: Date.now()
    }

    setMessages(prev => [...prev, userMessage])
    setInputValue('')
    setLoading(true)

    const controller = new AbortController()
    const { signal } = controller

    try {
      let aiResponse: string

      if (GEMINI_API_KEY) {
        // Use Gemini API
        aiResponse = await callGeminiAPI(inputValue.trim(), messages, signal)
      } else {
        // Use fallback responses
        await new Promise(resolve => setTimeout(resolve, 1500))
        aiResponse = generateFallbackResponse(inputValue.trim())
        setApiKeyMissing(true)
      }

      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: aiResponse,
        timestamp: Date.now()
      }

      setMessages(prev => [...prev, aiMessage])
    } catch (error) {
      if (error instanceof Error && error.name === 'AbortError') {
        return
      }
      const errorMessage = error instanceof Error ? error.message : 'Unknown error'
      messageApi.error(`AI Error: ${errorMessage}`)
      
      // Add error message
      const errorMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: 'I apologize, but I encountered an error. Please try again.',
        timestamp: Date.now()
      }
      setMessages(prev => [...prev, errorMsg])
    } finally {
      setLoading(false)
    }
  }

  const handleLogout = async (): Promise<void> => {
    try {
      await logout()
      messageApi.success('Successfully logged out')
    } catch {
      messageApi.error('Failed to logout')
    }
  }

  const userMenuItems = [
    {
      key: 'profile',
      label: 'Profile Settings',
      icon: <SettingOutlined />
    },
    {
      key: 'logout',
      label: 'Logout',
      icon: <LogoutOutlined />,
      danger: true
    }
  ]

  const brandColors = {
    red: '#E31837',
    green: '#009639',
    black: '#1D1D1B',
    lightGray: '#F5F5F5',
    border: '#E8E8E8'
  }

  const renderMessage = (msg: Message) => {
    const isUser = msg.role === 'user'
    return (
      <div
        key={msg.id}
        style={{
          ...styles.messageRow,
          justifyContent: isUser ? 'flex-end' : 'flex-start'
        }}
      >
        <div style={{
          ...styles.messageWrapper,
          backgroundColor: isUser ? brandColors.green : '#FFFFFF',
          border: isUser ? 'none' : `1px solid ${brandColors.border}`,
          borderRadius: isUser ? '16px 16px 4px 16px' : '16px 16px 16px 4px'
        }}>
          <Space align="start" size={12}>
            {!isUser && (
              <Avatar
                size={32}
                icon={<RobotOutlined />}
                style={{ backgroundColor: brandColors.green }}
              />
            )}
            <div>
              <Text
                style={{
                  color: isUser ? '#FFFFFF' : brandColors.black,
                  fontSize: '14px',
                  lineHeight: 1.6,
                  whiteSpace: 'pre-wrap'
                }}
              >
                {msg.content}
              </Text>
            </div>
            {isUser && user?.photoURL && (
              <Avatar
                size={32}
                src={user.photoURL}
                style={{ backgroundColor: brandColors.green }}
              />
            )}
          </Space>
        </div>
      </div>
    )
  }

  const promptItems = [
    {
      key: '1',
      title: 'Explain quantum computing',
      icon: <RobotOutlined />,
      onClick: () => setInputValue('Explain quantum computing in simple terms')
    },
    {
      key: '2',
      title: 'Help me write code',
      icon: <RobotOutlined />,
      onClick: () => setInputValue('Help me write a React component')
    },
    {
      key: '3',
      title: 'Analyze data',
      icon: <RobotOutlined />,
      onClick: () => setInputValue('How to analyze large datasets efficiently')
    }
  ]

  return (
    <XProvider
      theme={{
        token: {
          colorPrimary: brandColors.green,
          borderRadius: 8
        }
      }}
    >
      <Layout style={styles.layout}>
        {contextHolder}

        {/* API Key Warning */}
        {apiKeyMissing && (
          <div style={styles.warningBanner}>
            <Text style={{ color: '#994B00' }}>
              ⚠️ Gemini API key not configured. Using demo responses. 
              Add VITE_GEMINI_API_KEY to your .env file for real AI responses.
            </Text>
          </div>
        )}

        {/* Sidebar */}
        <Sider
          width={280}
          collapsed={siderCollapsed}
          collapsedWidth={0}
          style={styles.sider}
          trigger={null}
        >
          <div style={styles.siderHeader}>
            {!siderCollapsed && (
              <div style={styles.siderLogo}>
                <Logo size="small" />
              </div>
            )}
            <Button
              type="text"
              icon={<PlusOutlined />}
              style={styles.newChatButton}
            >
              {!siderCollapsed && 'New Chat'}
            </Button>
          </div>

          {!siderCollapsed && (
            <div style={styles.conversations}>
              <Text style={styles.sectionTitle}>Recent Conversations</Text>
              {conversations.map(conv => (
                <div
                  key={conv.id}
                  style={{
                    ...styles.conversationItem,
                    backgroundColor: activeConversation === conv.id ? brandColors.lightGray : 'transparent'
                  }}
                  onClick={() => setActiveConversation(conv.id)}
                >
                  <Text
                    style={{
                      ...styles.conversationTitle,
                      color: activeConversation === conv.id ? brandColors.black : '#666'
                    }}
                    ellipsis
                  >
                    {conv.title}
                  </Text>
                </div>
              ))}
            </div>
          )}
        </Sider>

        {/* Main Content */}
        <Layout>
          <Header style={styles.header}>
            <Space size={16}>
              <Button
                type="text"
                icon={<MenuOutlined />}
                onClick={() => setSiderCollapsed(!siderCollapsed)}
                style={styles.menuButton}
              />
              <Badge dot={false}>
                <Logo size="small" />
              </Badge>
            </Space>

            <Space size={12}>
              <Dropdown
                menu={{ items: userMenuItems, onClick: ({ key }) => key === 'logout' && handleLogout() }}
                trigger={['click']}
                placement="bottomRight"
              >
                <Space style={styles.userInfo}>
                  <Avatar
                    src={user?.photoURL}
                    icon={!user?.photoURL && <UserOutlined />}
                    size={36}
                    style={{ backgroundColor: brandColors.green }}
                  />
                  <Text style={styles.userName}>{user?.displayName || user?.email || 'User'}</Text>
                </Space>
              </Dropdown>
            </Space>
          </Header>

          <Content style={styles.content}>
            <div style={styles.chatContainer}>
              {/* Chat Messages */}
              <div style={styles.messagesArea}>
                {messages.map(renderMessage)}
                {loading && (
                  <div style={styles.loadingIndicator}>
                    <Avatar
                      size={40}
                      icon={<RobotOutlined />}
                      style={{ backgroundColor: brandColors.green }}
                    />
                    <div style={styles.loadingDots}>
                      <span></span>
                      <span></span>
                      <span></span>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Quick Prompts */}
              {messages.length <= 1 && (
                <div style={styles.promptsContainer}>
                  <Text style={styles.promptsTitle}>Try asking me about:</Text>
                  <div style={styles.promptsGrid}>
                    {promptItems.map(item => (
                      <div
                        key={item.key}
                        style={styles.promptCard}
                        onClick={item.onClick}
                      >
                        <Space size={8}>
                          {item.icon}
                          <Text style={styles.promptText}>{item.title}</Text>
                        </Space>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Input Area */}
              <div style={styles.inputArea}>
                <div style={styles.inputWrapper}>
                  <Input.TextArea
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onPressEnter={(e) => {
                      if (!e.shiftKey) {
                        e.preventDefault()
                        handleSend()
                      }
                    }}
                    placeholder="Type your message..."
                    autoSize={{ minRows: 1, maxRows: 4 }}
                    style={styles.textArea}
                  />
                  <Button
                    type="primary"
                    icon={<SendOutlined />}
                    onClick={handleSend}
                    loading={loading}
                    style={styles.sendButton}
                    disabled={!inputValue.trim()}
                  />
                </div>
                <Text style={styles.disclaimer}>
                  AI can make mistakes. Please verify important information.
                </Text>
              </div>
            </div>
          </Content>
        </Layout>
      </Layout>
    </XProvider>
  )
}

const styles: Record<string, React.CSSProperties> = {
  layout: {
    minHeight: '100vh',
    background: '#FFFFFF'
  },
  warningBanner: {
    background: '#FFF7E6',
    padding: '8px 24px',
    borderBottom: '1px solid #FFE7BA',
    textAlign: 'center'
  },
  sider: {
    background: '#FFFFFF',
    borderRight: '1px solid #E8E8E8'
  },
  siderHeader: {
    padding: '16px',
    borderBottom: '1px solid #E8E8E8'
  },
  siderLogo: {
    marginBottom: '12px'
  },
  newChatButton: {
    width: '100%',
    height: '44px',
    borderRadius: '8px',
    border: '1px solid #E8E8E8',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',
    color: '#1D1D1B',
    fontWeight: 500
  },
  conversations: {
    padding: '16px',
    overflowY: 'auto'
  },
  sectionTitle: {
    fontSize: '12px',
    fontWeight: 500,
    color: '#8C8C8C',
    textTransform: 'uppercase',
    letterSpacing: '0.5px',
    marginBottom: '12px',
    display: 'block'
  },
  conversationItem: {
    padding: '10px 12px',
    borderRadius: '8px',
    cursor: 'pointer',
    marginBottom: '4px',
    transition: 'background-color 0.2s'
  },
  conversationTitle: {
    fontSize: '14px',
    fontWeight: 500
  },
  header: {
    background: '#FFFFFF',
    padding: '0 24px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderBottom: '1px solid #E8E8E8',
    height: '64px',
    lineHeight: '64px'
  },
  menuButton: {
    fontSize: '18px',
    color: '#1D1D1B'
  },
  userInfo: {
    cursor: 'pointer',
    padding: '4px 8px',
    borderRadius: '8px',
    transition: 'background-color 0.2s'
  },
  userName: {
    fontWeight: 500,
    color: '#1D1D1B'
  },
  content: {
    background: '#FAFAFA'
  },
  chatContainer: {
    maxWidth: '900px',
    margin: '0 auto',
    height: 'calc(100vh - 64px)',
    display: 'flex',
    flexDirection: 'column'
  },
  messagesArea: {
    flex: 1,
    overflowY: 'auto',
    padding: '24px'
  },
  messageRow: {
    display: 'flex',
    marginBottom: '16px'
  },
  messageWrapper: {
    padding: '12px 16px',
    maxWidth: '70%',
    boxShadow: '0 1px 2px rgba(0, 0, 0, 0.04)'
  },
  loadingIndicator: {
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
    padding: '16px 0'
  },
  loadingDots: {
    display: 'flex',
    gap: '4px'
  },
  promptsContainer: {
    padding: '0 24px',
    marginBottom: '16px'
  },
  promptsTitle: {
    fontSize: '14px',
    fontWeight: 500,
    color: '#666',
    marginBottom: '12px',
    display: 'block'
  },
  promptsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
    gap: '12px'
  },
  promptCard: {
    padding: '12px 16px',
    background: '#FFFFFF',
    border: '1px solid #E8E8E8',
    borderRadius: '8px',
    cursor: 'pointer',
    transition: 'all 0.2s ease'
  },
  promptText: {
    fontSize: '14px',
    fontWeight: 500,
    color: '#1D1D1B'
  },
  inputArea: {
    padding: '16px 24px 24px',
    background: '#FFFFFF',
    borderTop: '1px solid #E8E8E8'
  },
  inputWrapper: {
    display: 'flex',
    gap: '12px',
    alignItems: 'flex-end'
  },
  textArea: {
    flex: 1,
    borderRadius: '12px',
    border: '1px solid #E8E8E8',
    resize: 'none',
    boxShadow: '0 2px 8px rgba(0, 0, 0, 0.04)'
  },
  sendButton: {
    height: '44px',
    borderRadius: '12px',
    background: 'linear-gradient(135deg, #009639 0%, #007a2e 100%)',
    border: 'none'
  },
  disclaimer: {
    display: 'block',
    textAlign: 'center',
    fontSize: '12px',
    color: '#8C8C8C',
    marginTop: '12px'
  }
}

export default Chat
